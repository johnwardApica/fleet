#!/bin/sh

mkdir -p /opt/apica/bin/
cp apica-otel-linux_amd64 /opt/apica/bin/

mkdir -p /etc/otelcol/
