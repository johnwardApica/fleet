#!/bin/sh

rm /opt/apica/bin/apica-otel-linux_amd64

